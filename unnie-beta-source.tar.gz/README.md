# UNNIE Beta 0.1

Android test build for private use.

Core test scope:
- Minimal bright editorial UI inspired by EmmaKwon.com
- Local record list
- New note / edit / autosave
- Date-first sorting
- Native camera and gallery import
- 3:4, 1:1, 9:16 image crop
- Insert image at text cursor
- Normal / large / extra-large text
- Delete note / delete photo
- TXT export
- Instagram 4:5 JPG export (single-page beta renderer)

This branch exists only to produce an installable test APK.
