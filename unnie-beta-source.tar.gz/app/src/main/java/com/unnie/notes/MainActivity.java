package com.unnie.notes;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.exifinterface.media.ExifInterface;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQ_CAMERA = 7001;
    private static final int REQ_GALLERY = 7002;
    private static final int REQ_SAVE_TEXT = 7003;
    private static final int REQ_SAVE_IMAGE = 7004;
    private static final int REQ_CAMERA_PERMISSION = 7005;

    private WebView webView;
    private Uri cameraUri;
    private String pendingText;
    private byte[] pendingImageBytes;
    private String pendingImageMime = "image/jpeg";
    private boolean waitingForCameraPermission = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(android.graphics.Color.rgb(255, 249, 251));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(251, 252, 255));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setDefaultTextEncodingName("utf-8");

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new NativeBridge(), "Android");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class NativeBridge {
        @JavascriptInterface
        public String loadState() {
            return getSharedPreferences("unnie", MODE_PRIVATE)
                    .getString("state", "");
        }

        @JavascriptInterface
        public void saveState(String json) {
            getSharedPreferences("unnie", MODE_PRIVATE)
                    .edit()
                    .putString("state", json == null ? "" : json)
                    .apply();
        }

        @JavascriptInterface
        public void pickCamera() {
            runOnUiThread(() -> {
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA)
                        != PackageManager.PERMISSION_GRANTED) {
                    waitingForCameraPermission = true;
                    ActivityCompat.requestPermissions(MainActivity.this,
                            new String[]{Manifest.permission.CAMERA}, REQ_CAMERA_PERMISSION);
                    return;
                }
                launchCamera();
            });
        }

        @JavascriptInterface
        public void pickGallery() {
            runOnUiThread(MainActivity.this::launchGallery);
        }

        @JavascriptInterface
        public void saveText(String filename, String content) {
            runOnUiThread(() -> {
                pendingText = content == null ? "" : content;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_TITLE,
                        filename == null || filename.isBlank() ? "unnie.txt" : filename);
                startActivityForResult(intent, REQ_SAVE_TEXT);
            });
        }

        @JavascriptInterface
        public void saveImage(String filename, String dataUrl) {
            runOnUiThread(() -> {
                try {
                    String value = dataUrl == null ? "" : dataUrl;
                    int comma = value.indexOf(',');
                    String header = comma >= 0 ? value.substring(0, comma) : "";
                    String base64 = comma >= 0 ? value.substring(comma + 1) : value;
                    pendingImageBytes = Base64.decode(base64, Base64.DEFAULT);
                    pendingImageMime = header.contains("image/png") ? "image/png" : "image/jpeg";

                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType(pendingImageMime);
                    intent.putExtra(Intent.EXTRA_TITLE,
                            filename == null || filename.isBlank()
                                    ? (pendingImageMime.equals("image/png") ? "unnie.png" : "unnie.jpg")
                                    : filename);
                    startActivityForResult(intent, REQ_SAVE_IMAGE);
                } catch (Exception error) {
                    toast("이미지를 저장할 수 없어요.");
                }
            });
        }
    }

    private void launchCamera() {
        try {
            File dir = new File(getCacheDir(), "camera");
            if (!dir.exists()) dir.mkdirs();
            File file = File.createTempFile("unnie_", ".jpg", dir);
            cameraUri = FileProvider.getUriForFile(
                    this,
                    getPackageName() + ".fileprovider",
                    file
            );

            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            if (intent.resolveActivity(getPackageManager()) == null) {
                toast("카메라 앱을 찾을 수 없어요.");
                return;
            }
            startActivityForResult(intent, REQ_CAMERA);
        } catch (Exception error) {
            toast("카메라를 열 수 없어요.");
        }
    }

    private void launchGallery() {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("image/*");
            startActivityForResult(intent, REQ_GALLERY);
        } catch (Exception error) {
            toast("갤러리를 열 수 없어요.");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CAMERA_PERMISSION) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (granted && waitingForCameraPermission) {
                waitingForCameraPermission = false;
                launchCamera();
            } else {
                waitingForCameraPermission = false;
                toast("사진을 찍으려면 카메라 권한이 필요해요.");
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK) return;

        if (requestCode == REQ_CAMERA && cameraUri != null) {
            deliverImage(cameraUri);
            return;
        }

        if (requestCode == REQ_GALLERY && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(
                        uri,
                        data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                );
            } catch (Exception ignored) {
            }
            deliverImage(uri);
            return;
        }

        if (requestCode == REQ_SAVE_TEXT && data != null && data.getData() != null) {
            writeText(data.getData());
            return;
        }

        if (requestCode == REQ_SAVE_IMAGE && data != null && data.getData() != null) {
            writeImage(data.getData());
        }
    }

    private void deliverImage(Uri uri) {
        new Thread(() -> {
            try {
                Bitmap bitmap = decodeOrientedBitmap(uri, 2200);
                if (bitmap == null) throw new IOException("bitmap decode failed");

                ByteArrayOutputStream output = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 90, output);
                bitmap.recycle();
                String base64 = Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP);
                String dataUrl = "data:image/jpeg;base64," + base64;

                runOnUiThread(() -> webView.evaluateJavascript(
                        "window.UNNIE && window.UNNIE.receivePhoto(" + JSONObject.quote(dataUrl) + ");",
                        null
                ));
            } catch (Exception error) {
                runOnUiThread(() -> toast("사진을 불러올 수 없어요."));
            }
        }).start();
    }

    private Bitmap decodeOrientedBitmap(Uri uri, int maxDimension) throws IOException {
        ContentResolver resolver = getContentResolver();
        byte[] bytes;
        try (InputStream input = resolver.openInputStream(uri)) {
            if (input == null) return null;
            bytes = readAll(input);
        }

        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(bytes, 0, bytes.length, bounds);
        int largest = Math.max(bounds.outWidth, bounds.outHeight);
        int sample = 1;
        while (largest / sample > maxDimension * 1.35f) sample *= 2;

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = sample;
        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length, options);
        if (bitmap == null) return null;

        int orientation = ExifInterface.ORIENTATION_NORMAL;
        try (InputStream exifInput = resolver.openInputStream(uri)) {
            if (exifInput != null) {
                ExifInterface exif = new ExifInterface(exifInput);
                orientation = exif.getAttributeInt(
                        ExifInterface.TAG_ORIENTATION,
                        ExifInterface.ORIENTATION_NORMAL
                );
            }
        } catch (Exception ignored) {
        }

        Matrix matrix = new Matrix();
        if (orientation == ExifInterface.ORIENTATION_ROTATE_90) matrix.postRotate(90);
        else if (orientation == ExifInterface.ORIENTATION_ROTATE_180) matrix.postRotate(180);
        else if (orientation == ExifInterface.ORIENTATION_ROTATE_270) matrix.postRotate(270);

        Bitmap rotated = bitmap;
        if (!matrix.isIdentity()) {
            rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
            if (rotated != bitmap) bitmap.recycle();
        }

        int width = rotated.getWidth();
        int height = rotated.getHeight();
        float scale = Math.min(1f, maxDimension / (float)Math.max(width, height));
        if (scale < 1f) {
            Bitmap scaled = Bitmap.createScaledBitmap(rotated,
                    Math.max(1, Math.round(width * scale)),
                    Math.max(1, Math.round(height * scale)), true);
            if (scaled != rotated) rotated.recycle();
            return scaled;
        }
        return rotated;
    }

    private byte[] readAll(InputStream input) throws IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] buffer = new byte[16 * 1024];
        int read;
        while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
        return output.toByteArray();
    }

    private void writeText(Uri uri) {
        try (OutputStream output = getContentResolver().openOutputStream(uri)) {
            if (output == null) throw new IOException("output stream unavailable");
            output.write((pendingText == null ? "" : pendingText).getBytes(StandardCharsets.UTF_8));
            output.flush();
            toast("TXT 파일을 저장했어요.");
        } catch (Exception error) {
            toast("TXT 파일을 저장하지 못했어요.");
        } finally {
            pendingText = null;
        }
    }

    private void writeImage(Uri uri) {
        try (OutputStream output = getContentResolver().openOutputStream(uri)) {
            if (output == null || pendingImageBytes == null) throw new IOException("output unavailable");
            output.write(pendingImageBytes);
            output.flush();
            toast("이미지를 저장했어요.");
        } catch (Exception error) {
            toast("이미지를 저장하지 못했어요.");
        } finally {
            pendingImageBytes = null;
        }
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onBackPressed() {
        webView.evaluateJavascript(
                "(window.UNNIE && window.UNNIE.handleBack) ? window.UNNIE.handleBack() : false;",
                value -> {
                    if ("true".equals(value)) return;
                    MainActivity.super.onBackPressed();
                }
        );
    }
}
